<?php
if (!defined('APP')) die('No direct access');

/* ===== COMPAT LAYER (PHP 5.4+) ===== */
if (!function_exists('random_bytes')) {
  function random_bytes($len){ 
    if (function_exists('openssl_random_pseudo_bytes')) {
      $strong = false; $b = openssl_random_pseudo_bytes($len, $strong);
      if ($b !== false && $strong) return $b;
    }
    $out = ''; for($i=0;$i<$len;$i++){ $out .= chr(mt_rand(0,255)); } return $out;
  }
}
if (!function_exists('password_hash')) {
  // very basic fallback (NOT bcrypt). Use only on old PHP; recommend upgrading.
  function password_hash($password, $algo){ return sha1($password); }
  function password_verify($password, $hash){ return sha1($password)===$hash; }
}

function app_path($p){ return __DIR__.($p?('/'.$p):''); }
function is_installed(){ return file_exists(app_path('data/installed.json')); }

function cfg(){
  static $c=null; if($c!==null) return $c;
  if(!file_exists(app_path('config.php'))) die('config.php fehlt. Bitte Installer ausführen.');
  $c = include app_path('config.php');
  if (!isset($c['salt']) || !$c['salt']) $c['salt'] = bin2hex(random_bytes(16));
  if (!isset($c['base_url']) || !$c['base_url']) {
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = isset($_SERVER['HTTP_HOST'])? $_SERVER['HTTP_HOST'] : 'localhost';
    $script = isset($_SERVER['SCRIPT_NAME'])? $_SERVER['SCRIPT_NAME'] : '/showpanel/index.php';
    $path = rtrim(str_replace('\\','/', dirname($script)), '/');
    $c['base_url'] = $scheme.'://'.$host.$path;
  }
  return $c;
}
function json_path($name){ return app_path('data/'.$name.'.json'); }
function load_json($name, $default){
  $p = json_path($name);
  if(!file_exists($p)){
    if(!is_dir(dirname($p))) mkdir(dirname($p), 0775, true);
    file_put_contents($p, json_encode($default, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
    return $default;
  }
  $txt = @file_get_contents($p);
  $data = json_decode($txt, true);
  if(!is_array($data)) $data=$default;
  return $data;
}
function save_json($name, $data){
  $p = json_path($name);
  if(!is_dir(dirname($p))) mkdir(dirname($p), 0775, true);
  file_put_contents($p, json_encode($data, JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE));
}
function next_id(&$arr){ $max=0; foreach($arr as $o){ if(isset($o['id'])) $max=max($max,(int)$o['id']); } return $max+1; }
function yt_id($url){
  if(!$url) return '';
  if(preg_match('~youtu\.be/([\w-]{6,})~',$url,$m)) return $m[1];
  if(preg_match('~v=([\w-]{6,})~',$url,$m)) return $m[1];
  if(preg_match('~\/embed\/([\w-]{6,})~',$url,$m)) return $m[1];
  return '';
}
function esc($s){ return htmlspecialchars((string)$s, ENT_QUOTES,'UTF-8'); }
function is_admin(){ if(session_status()===PHP_SESSION_NONE) session_start(); return !empty($_SESSION['admin_logged_in']); }
function require_admin(){ if(!is_admin()){ header('Location: admin.php'); exit; } }
function ip_today_key($cid){ $ip=isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'0.0.0.0'; return $ip.'|'.$cid.'|'.date('Y-m-d'); }
function ensure_data(){
  $files = array('shows','episodes','candidates','jurors','votes','jury_votes','liveziel','iplog','logo','settings','jury_stars','final_ticket');
  foreach($files as $f){ load_json($f, array()); }
}
function seed_demo(){
  $shows = load_json('shows', array()); if($shows) return;
  $shows = array(
    array('id'=>1,'title'=>'Show Me Your Voice','slug'=>'show-me-your-voice'),
    array('id'=>2,'title'=>'Singfluence','slug'=>'singfluence')
  );
  $episodes=array(
    array('id'=>1,'show_id'=>1,'title'=>'Wildcard','slug'=>'wildcard','type'=>'wildcard','voting'=>'regular','voting_enabled'=>true,'liveziel_enabled'=>true,'goal'=>800,'gifts'=>array(array('name'=>'Rose','value'=>1),array('name'=>'Star','value'=>5),array('name'=>'Galaxy','value'=>20))),
    array('id'=>2,'show_id'=>1,'title'=>'Casting 1','slug'=>'casting-1','type'=>'casting','voting'=>'mixed','voting_enabled'=>true,'liveziel_enabled'=>true,'goal'=>1500,'gifts'=>array(array('name'=>'Rose','value'=>1),array('name'=>'Star','value'=>5),array('name'=>'Galaxy','value'=>20)),'rule'=>array('enabled'=>true,'required_yes'=>2,'yes_threshold'=>8,'viewer_vote_mode'=>'tool')),
    array('id'=>3,'show_id'=>2,'title'=>'Finale','slug'=>'finale','type'=>'finale','voting'=>'esc','voting_enabled'=>false,'liveziel_enabled'=>true,'goal'=>2000,'gifts'=>array(array('name'=>'Light','value'=>2),array('name'=>'Wave','value'=>6),array('name'=>'Crown','value'=>25)))
  );
  $candidates=array(
    array('id'=>1,'show_id'=>1,'episode_id'=>1,'name'=>'Lena Lights','youtube'=>'https://youtu.be/dQw4w9WgXcQ','active'=>1,'city'=>'Berlin','phone'=>'','reason'=>'Musik ist mein Leben','photo'=>''),
    array('id'=>2,'show_id'=>1,'episode_id'=>2,'name'=>'Milo Beats','youtube'=>'https://youtu.be/oHg5SJYRHA0','active'=>1,'city'=>'Hamburg','phone'=>'','reason'=>'Beatmaker','photo'=>''),
    array('id'=>3,'show_id'=>2,'episode_id'=>3,'name'=>'Nova Vox','youtube'=>'https://youtu.be/dQw4w9WgXcQ','active'=>1,'city'=>'Köln','phone'=>'','reason'=>'Vocal artist','photo'=>'')
  );
  $jurors=array( array('id'=>1,'show_id'=>1,'name'=>'Alex','token'=>''), array('id'=>2,'show_id'=>1,'name'=>'Ben','token'=>''), array('id'=>3,'show_id'=>2,'name'=>'Jamie','token'=>'') );
  $votes=array( 1=>array('yes'=>25,'no'=>3), 2=>array('yes'=>10,'no'=>2), 3=>array('yes'=>18,'no'=>1) );
  $jury_votes=array();
  $liveziel=array( 1=>array(1=>array('g1'=>2,'g2'=>1,'g3'=>0)), 2=>array(2=>array('g1'=>0,'g2'=>2,'g3'=>1)), 3=>array(3=>array('g1'=>0,'g2'=>1,'g3'=>0)) );
  $logo=array( 1=>'assets/demo/logo.png', 2=>'assets/demo/logo.png' );
  $settings=array( 
    'theme'=>array('bg'=>'#0f0f10','card'=>'#16171a','accent'=>'#ff0050','ok'=>'#00d07e','danger'=>'#c62828','border'=>'#2a2c30','radius'=>14),
    'logo_default'=>'assets/demo/logo.png',
    'active_view'=>array('show_id'=>1,'episode_id'=>1)
  );
  $jury_stars = array(); $final_ticket = array();
  save_json('shows',$shows); save_json('episodes',$episodes); save_json('candidates',$candidates);
  save_json('jurors',$jurors); save_json('votes',$votes); save_json('jury_votes',$jury_votes);
  save_json('liveziel',$liveziel); save_json('logo',$logo); save_json('settings',$settings);
  save_json('jury_stars',$jury_stars); save_json('final_ticket',$final_ticket);
}
function theme_style_tag(){
  $s = load_json('settings', array()); $t = isset($s['theme'])? $s['theme'] : array();
  $bg = isset($t['bg'])?$t['bg']:'#0f0f10'; $card = isset($t['card'])?$t['card']:'#16171a'; $accent = isset($t['accent'])?$t['accent']:'#ff0050';
  $ok = isset($t['ok'])?$t['ok']:'#00d07e'; $danger = isset($t['danger'])?$t['danger']:'#c62828'; $border = isset($t['border'])?$t['border']:'#2a2c30'; $radius=(int)(isset($t['radius'])?$t['radius']:14);
  echo '<style>:root{--bg:'.$bg.';--card:'.$card.';--accent:'.$accent.';--ok:'.$ok.';--danger:'.$danger.';--border:'.$border.';--radius:'.$radius.'px}</style>';
}

/* helpers to avoid arrow functions */
function arr_filter_by($arr, $key, $val){
  $out = array(); foreach($arr as $row){ if(isset($row[$key]) && $row[$key]==$val) $out[]=$row; } return $out;
}
function arr_find_by_id($arr, $id){
  foreach($arr as $row){ if(isset($row['id']) && (int)$row['id']==(int)$id) return $row; } return null;
}
function arr_index_by_id(&$arr, $id){
  foreach($arr as $i=>$row){ if(isset($row['id']) && (int)$row['id']==(int)$id) return $i; } return -1;
}
