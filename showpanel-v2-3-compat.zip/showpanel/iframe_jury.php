<?php
define('APP',1); require __DIR__.'/lib.php'; if (!is_installed()) { header('Location: installer.php'); exit; }
$token = preg_replace('~[^a-f0-9]~','', isset($_GET['token'])?$_GET['token']:'');
$episodes = load_json('episodes', array()); $jurors = load_json('jurors', array());
$juror = null; foreach($jurors as $j){ if((isset($j['token'])?$j['token']:'') === $token){ $juror=$j; break; } }
if(!$juror){ die('Token ungültig'); }
$show_id = (int)$juror['show_id'];
$eps = arr_filter_by($episodes, 'show_id', $show_id);
$ep_id = isset($_GET['episode']) ? (int)$_GET['episode'] : ( $eps ? $eps[0]['id'] : 0 );
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Jury Voting</title>
<link rel="stylesheet" href="assets/css/style.css"><?php theme_style_tag(); ?></head>
<body class="dark"><div class="wrap">
  <h3>Jury Voting – <?php echo esc($juror['name']); ?></h3>
  <form method="get" class="toolbar"><input type="hidden" name="token" value="<?php echo esc($token); ?>">
    <label>Episode
      <select name="episode" onchange="this.form.submit()">
        <?php foreach($eps as $e){ echo '<option value="'.$e['id'].'"'.($e['id']==$ep_id?' selected':'').'>'.esc($e['title']).'</option>'; } ?>
      </select>
    </label>
  </form>
  <?php $candidates = load_json('candidates', array()); $cands = array(); foreach($candidates as $c){ if($c['show_id']==$show_id && $c['active'] && (!$ep_id || $c['episode_id']==$ep_id)) $cands[]=$c; } ?>
  <form method="post" action="api.php">
    <input type="hidden" name="action" value="save_jury_points">
    <input type="hidden" name="token" value="<?php echo esc($token); ?>">
    <input type="hidden" name="episode_id" value="<?php echo (int)$ep_id; ?>">
    <table class="table"><thead><tr><th>Kandidat</th><th>Punkte (0–12)</th></tr></thead><tbody>
      <?php foreach($cands as $cand){ echo '<tr><td>'.esc($cand['name']).'</td><td><input type="number" name="pts['.$cand['id'].']" min="0" max="12" class="w80" value="0"></td></tr>'; } ?>
    </tbody></table>
    <button class="btn">Speichern</button>
  </form>
</div></body></html>
