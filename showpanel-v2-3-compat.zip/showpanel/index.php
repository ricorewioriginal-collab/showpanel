<?php
define('APP',1); require __DIR__.'/lib.php';
if (!is_installed()) { header('Location: installer.php'); exit; }

$settings = load_json('settings', array());
$shows = load_json('shows', array()); $episodes = load_json('episodes', array());
$candidates = load_json('candidates', array()); $logo = load_json('logo', array());
$votes = load_json('votes', array()); $liveziel = load_json('liveziel', array());
$jury_stars = load_json('jury_stars', array()); $final_ticket = load_json('final_ticket', array()); $jury_votes = load_json('jury_votes', array());

$active = isset($settings['active_view']) ? $settings['active_view'] : null;
if($active){
  $show_id = (int)$active['show_id'];
  $ep_id = (int)$active['episode_id'];
  $force_view = true;
}else{
  $force_view = false;
  $show_id = isset($_GET['show']) ? (int)$_GET['show'] : ( $shows ? $shows[0]['id'] : 0);
  $eps = arr_filter_by($episodes, 'show_id', $show_id);
  $ep_id = isset($_GET['episode']) ? (int)$_GET['episode'] : ( $eps ? $eps[0]['id'] : 0 );
}
$eps = arr_filter_by($episodes, 'show_id', $show_id);
$ep = arr_find_by_id($episodes, $ep_id);
$show_logo = isset($logo[$show_id]) ? $logo[$show_id] : ( (isset($settings['logo_default'])?$settings['logo_default']:'assets/demo/logo.png') );

$cards = array(); foreach($candidates as $c){ if($c['show_id']==$show_id && $c['active'] && (!$ep_id || $c['episode_id']==$ep_id)) $cards[]=$c; }
$gifts = isset($ep['gifts']) ? $ep['gifts'] : array(array('name'=>'Gift 1','value'=>1),array('name'=>'Gift 2','value'=>5),array('name'=>'Gift 3','value'=>10));
$goal = (int)(isset($ep['goal'])?$ep['goal']:0);
$voting_enabled = !empty($ep['voting_enabled']);
$lz_enabled = !empty($ep['liveziel_enabled']);
$embed = !empty($_GET['embed']);
?><!DOCTYPE html><html lang="de"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Show Voting</title>
<link rel="stylesheet" href="assets/css/style.css"><?php theme_style_tag(); ?>
<script src="assets/js/main.js" defer></script></head>
<body class="dark"><div class="wrap">
  <header class="header">
    <img class="logo" src="<?php echo esc($show_logo); ?>" alt="Logo">
    <?php if(!$force_view): ?>
    <form class="toolbar" method="get">
      <label>Show
        <select name="show" onchange="this.form.submit()">
          <?php foreach($shows as $s){ echo '<option value="'.$s['id'].'"'.($s['id']==$show_id?' selected':'').'>'.esc($s['title']).'</option>'; } ?>
        </select>
      </label>
      <label>Episode
        <select name="episode" onchange="this.form.submit()">
          <?php foreach($eps as $e){ echo '<option value="'.$e['id'].'"'.($e['id']==$ep_id?' selected':'').'>'.esc($e['title']).'</option>'; } ?>
        </select>
      </label>
      <a class="btn ghost" href="admin.php">Admin</a>
    </form>
    <?php endif; ?>
  </header>

  <div class="note">Die Show läuft <b>live auf TikTok</b> bei <b>@ricorewi</b> – hier kannst du parallel abstimmen und Replays schauen.</div>

  <div class="grid">
    <?php foreach($cards as $cand):
      $cid = $cand['id'];
      $yt = yt_id(isset($cand['youtube'])?$cand['youtube']:'');
      $v  = isset($votes[$cid]) ? $votes[$cid] : array('yes'=>0,'no'=>0);
      $lv = isset($liveziel[$ep_id][$cid]) ? $liveziel[$ep_id][$cid] : array('g1'=>0,'g2'=>0,'g3'=>0);
      $coins = ($lv['g1']*(isset($gifts[0]['value'])?$gifts[0]['value']:1)) + ($lv['g2']*(isset($gifts[1]['value'])?$gifts[1]['value']:5)) + ($lv['g3']*(isset($gifts[2]['value'])?$gifts[2]['value']:10));
      $pct = $goal? min(100, round($coins*100/$goal)) : 0;
      $stars = 0; if(isset($jury_stars[$show_id])){ foreach($jury_stars[$show_id] as $jid=>$cid_star){ if($cid_star==$cid) $stars++; } }
      $final = ( (int)(isset($final_ticket[$show_id])?$final_ticket[$show_id]:0) === $cid );

      $jury_yes = 0; $rule = isset($ep['rule']) ? $ep['rule'] : array('enabled'=>false,'required_yes'=>2,'yes_threshold'=>8,'viewer_vote_mode'=>'tool');
      $thr = isset($rule['yes_threshold'])?$rule['yes_threshold']:8;
      if(isset($jury_votes[$ep_id])){
        foreach($jury_votes[$ep_id] as $jid=>$map){
          if(isset($map[$cid])){ $p=(int)$map[$cid]; if($p >= $thr) $jury_yes++; }
        }
      }
      $is_wackel = !empty($rule['enabled']) && ($jury_yes >= (int)(isset($rule['required_yes'])?$rule['required_yes']:2));
      $viewer_mode = isset($rule['viewer_vote_mode'])?$rule['viewer_vote_mode']:'tool';
      $candidate_can_vote = $voting_enabled && ( empty($rule['enabled']) ? true : ($ep['type']==='wildcard' || ($viewer_mode==='tool' && $is_wackel)) );
    ?>
    <div class="card" data-cid="<?php echo $cid; ?>">
      <h3><?php echo esc($cand['name']); ?>
        <?php if($stars): ?><span class="badge">⭐ Golden Star × <?php echo $stars; ?></span><?php endif; ?>
        <?php if(!empty($rule['enabled'])): ?><span class="tag">Jury-JA: <?php echo $jury_yes; ?>/<?php echo (int)(isset($rule['required_yes'])?$rule['required_yes']:2); ?><?php if($is_wackel): ?> · Wackelkandidat<?php endif; ?></span><?php endif; ?>
        <?php if($final): ?><span class="badge">🏆 Finalticket</span><?php endif; ?>
      </h3>
      <div class="media">
        <?php if($yt): ?>
          <div class="ratio"><iframe src="https://www.youtube.com/embed/<?php echo esc($yt); ?>" allowfullscreen></iframe></div>
        <?php elseif(!empty($cand['photo'])): ?>
          <img class="photo" src="<?php echo esc($cand['photo']); ?>" alt="">
        <?php else: ?>
          <img class="photo" src="assets/demo/candidate.png" alt="">
        <?php endif; ?>
      </div>
      <div class="bars">
        <div class="bar"><span>Ja</span><div class="track"><div class="fill yes" style="width:<?php echo $v['yes']?min(100,$v['yes']*5):2; ?>%"></div></div><b>✔ <span class="yes-val"><?php echo $v['yes']; ?></span></b></div>
      </div>
      <?php if($candidate_can_vote): ?>
      <div class="vote">
        <button class="btn yes">✔ Ja</button>
        <button class="btn no">✖ Nein</button>
      </div>
      <?php else: ?>
      <div class="note">Abstimmung im Tool ist für diese Episode deaktiviert<?php if(!empty($rule['enabled']) && ($viewer_mode==='tiktok')) echo ' (Jury-Regel aktiv – Zuschauerentscheid via TikTok-Coins)'; ?>.</div>
      <?php endif; ?>

      <?php if($lz_enabled): ?>
      <div class="liveziel" style="margin-top:10px">
        <div class="lz-row">
          <div><?php echo esc($gifts[0]['name']); ?>: <b><?php echo (int)$lv['g1']; ?></b> × <?php echo (int)$gifts[0]['value']; ?></div>
          <div><?php echo esc($gifts[1]['name']); ?>: <b><?php echo (int)$lv['g2']; ?></b> × <?php echo (int)$gifts[1]['value']; ?></div>
          <div><?php echo esc($gifts[2]['name']); ?>: <b><?php echo (int)$lv['g3']; ?></b> × <?php echo (int)$gifts[2]['value']; ?></div>
        </div>
        <div class="lz-total"><span>Coins gesamt:</span> <b class="coins"><?php echo (int)$coins; ?></b>
          <?php if($goal): ?><div class="bar"><div class="track"><div class="fill" style="width:<?php echo $pct; ?>%"></div></div><span class="val"><?php echo $pct; ?>% von <?php echo $goal; ?></span></div><?php endif; ?>
        </div>
      </div>
      <?php endif; ?>
    </div>
    <?php endforeach; ?>
  </div>

</div></body></html>
