<?php
// Wird vom Installer überschrieben. Bei Bedarf manuell anpassen.
return array(
  'admin_user' => 'admin',
  // Passwort-Hash für "admin123" – wird im Installer ersetzt
  'admin_pass_hash' => 'a65e02abf3bbfd0dd9ba',
  'salt' => '',
  'base_url' => null
);
