document.addEventListener('click', function(e){
  var b = e.target.closest && e.target.closest('.card .btn');
  if(!b) return;
  var type = b.classList.contains('no') ? 'no' : 'yes';
  var card = b.closest('.card'); var cid = card.getAttribute('data-cid');
  var body = new URLSearchParams(); body.append('action','vote'); body.append('cid',cid); body.append('type',type);
  fetch('api.php', {method:'POST', headers:{'Accept':'application/json'}, body: body})
  .then(function(r){return r.json()}).then(function(d){
    if(!d.ok){ alert(d.msg||'Heute schon abgestimmt'); return; }
    card.querySelector('.yes-val').textContent = d.yes;
    card.querySelector('.fill.yes').style.width = (d.yes? Math.min(100, d.yes*5):2)+'%';
  }).catch(function(){ alert('Netzwerkfehler'); });
});