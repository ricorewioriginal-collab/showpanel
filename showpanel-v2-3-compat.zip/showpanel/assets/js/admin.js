function q(sel,root){return (root||document).querySelector(sel)}
function post(body){ return fetch('api.php',{method:'POST',headers:{'Accept':'application/json'},body: new URLSearchParams(body)}).then(function(r){return r.json()}) }
document.addEventListener('click', function(e){
  if(e.target.id==='save_show'){
    var show_id=e.target.getAttribute('data-show');
    post({action:'save_show', show_id:show_id, title:q('#show_title').value, logo:q('#show_logo').value}).then(function(){flash(e.target)})
  }
  if(e.target.classList.contains('save-ep')){
    var tr=e.target.closest('tr'); var id=tr.getAttribute('data-ep');
    post({action:'save_episode', id:id,
      title: q('.ep-title',tr).value, type: q('.ep-type',tr).value,
      voting:q('.ep-voting',tr).value, goal:q('.ep-goal',tr).value,
      voting_enabled: q('.ep-ven',tr).checked ? '1' : '0',
      liveziel_enabled: q('.ep-lzen',tr).checked ? '1' : '0',
      g1n:q('.ep-g1-name',tr).value, g1v:q('.ep-g1-val',tr).value,
      g2n:q('.ep-g2-name',tr).value, g2v:q('.ep-g2-val',tr).value,
      g3n:q('.ep-g3-name',tr).value, g3v:q('.ep-g3-val',tr).value,
      rule_enabled: q('.ep-rule-en',tr)&&q('.ep-rule-en',tr).checked ? '1' : '0',
      rule_req: q('.ep-rule-req',tr)?q('.ep-rule-req',tr).value:'2',
      rule_thr: q('.ep-rule-thr',tr)?q('.ep-rule-thr',tr).value:'8',
      rule_mode: q('.ep-rule-mode',tr)?q('.ep-rule-mode',tr).value:'tool'
    }).then(function(){flash(tr)})
  }
  if(e.target.id==='add_episode'){
    var show=e.target.getAttribute('data-show'), title=q('#new_ep_title').value || 'Neue Folge';
    post({action:'add_episode', show:show, title:title}).then(function(){location.reload()});
  }
  if(e.target.classList.contains('save-cand')){
    var tr=e.target.closest('tr'); var id=tr.getAttribute('data-cid');
    post({action:'save_candidate', id:id,
      name:q('.cand-name',tr).value, episode_id:q('.cand-ep',tr).value,
      youtube:q('.cand-yt',tr).value, photo:q('.cand-photo',tr).value,
      city:q('.cand-city',tr).value, phone:q('.cand-phone',tr).value,
      active:q('.cand-active',tr).checked?'1':'0',
      yes:q('.cand-yes',tr).value, no:q('.cand-no',tr).value
    }).then(function(){flash(tr)});
  }
  if(e.target.classList.contains('del-cand')){
    if(!confirm('Kandidat löschen?')) return;
    var tr=e.target.closest('tr'); var id=tr.getAttribute('data-cid');
    post({action:'del_candidate', id:id}).then(function(){ tr.remove(); });
  }
  if(e.target.id==='add_candidate'){
    var show=e.target.getAttribute('data-show'), episode=e.target.getAttribute('data-episode'), name=q('#new_cand_name').value || 'Neuer Kandidat';
    post({action:'add_candidate', show:show, episode:episode, name:name}).then(function(){location.reload()});
  }
  if(e.target.id==='add_juror'){
    var show=e.target.getAttribute('data-show'), name=q('#new_jur_name').value || 'Neuer Juror';
    post({action:'add_juror', show:show, name:name}).then(function(){location.reload()});
  }
  if(e.target.classList.contains('del-juror')){
    if(!confirm('Juror löschen?')) return;
    var tr=e.target.closest('tr'); var id=tr.getAttribute('data-jid');
    post({action:'del_juror', id:id}).then(function(){ tr.remove(); });
  }
  if(e.target.classList.contains('make-token')){
    var tr=e.target.closest('tr'); var id=tr.getAttribute('data-jid');
    post({action:'make_token', id:id}).then(function(d){
      if(d.ok){ q('.tok-cell',tr).innerHTML = '<input class="w360 tok-url" value="'+d.url+'" readonly>'; }
    });
  }
  if(e.target.id==='set_active_view'){
    var show=q('#av_show').value, episode=q('#av_episode').value;
    post({action:'set_active_view', show:show, episode:episode}).then(function(){flash(e.target)});
  }
  if(e.target.classList.contains('set-star')){
    var tr=e.target.closest('tr'); var jid=tr.getAttribute('data-jid'); var cid=q('.star-cand',tr).value;
    post({action:'set_golden_star', juror_id:jid, candidate_id:cid}).then(function(d){
      if(!d.ok) alert(d.msg||'Fehler'); else flash(tr);
    });
  }
  if(e.target.id==='set_final_ticket'){
    var cid=q('#final_cand').value; var show=q('#final_show').value;
    post({action:'set_final_ticket', show:show, candidate_id:cid}).then(function(d){
      if(!d.ok) alert(d.msg||'Fehler'); else flash(e.target);
    });
  }
  if(e.target.classList.contains('lz-inc') || e.target.classList.contains('lz-dec')){
    var tr=e.target.closest('tr'); var cid=tr.getAttribute('data-cid'); var g=e.target.getAttribute('data-g');
    var delta = e.target.classList.contains('lz-inc') ? 1 : -1;
    var ep = (new URLSearchParams(location.search)).get('episode') || '';
    post({action:'lz_update', cid:cid, g:g, delta:delta, episode_id:ep}).then(function(d){
      if(d.ok){
        q('.lz-val[data-g="'+g+'"]',tr).textContent = d.row[g];
        var g1=parseInt(q('.lz-val[data-g="g1"]',tr).textContent||0,10);
        var g2=parseInt(q('.lz-val[data-g="g2"]',tr).textContent||0,10);
        var g3=parseInt(q('.lz-val[data-g="g3"]',tr).textContent||0,10);
        var row = document.querySelector('#ep_table tbody tr') || document.body;
        var g1v=parseInt((row.querySelector('.ep-g1-val')||{value:1}).value,10)||1;
        var g2v=parseInt((row.querySelector('.ep-g2-val')||{value:5}).value,10)||5;
        var g3v=parseInt((row.querySelector('.ep-g3-val')||{value:10}).value,10)||10;
        q('.lz-coins',tr).textContent = (g1*g1v + g2*g2v + g3*g3v);
      }
    });
  }
});
function flash(el){ el.classList.add('flash'); setTimeout(function(){el.classList.remove('flash')}, 800); }
