<?php
define('APP',1); require __DIR__.'/lib.php';
if (is_installed()) { header('Location: admin.php'); exit; }

$errors=array();
function can_write($p){ if(!file_exists($p)){ @mkdir($p,0775,true); } return is_writable($p); }

if($_SERVER['REQUEST_METHOD']==='POST'){
  $user = isset($_POST['user'])?trim($_POST['user']):'admin';
  $pass = isset($_POST['pass'])?$_POST['pass']:'';
  $base = isset($_POST['base_url'])?trim($_POST['base_url']):'';
  $seed = !empty($_POST['seed']);
  if(strlen($user)<3) $errors[]='Benutzername zu kurz';
  if(strlen($pass)<6) $errors[]='Passwort zu kurz (min. 6 Zeichen)';
  if(!$errors){
    $salt = bin2hex(random_bytes(16));
    $hash = password_hash($pass, 1);
    $cfg = "<?php\nreturn array(\n  'admin_user' => '".addslashes($user)."',\n  'admin_pass_hash' => '".addslashes($hash)."',\n  'salt' => '".addslashes($salt)."',\n  'base_url' => ".($base?("'".addslashes($base)."'"):'null')."\n);\n";
    file_put_contents(app_path('config.php'), $cfg);
    ensure_data();
    if($seed) seed_demo();
    save_json('installed', array('time'=>time(), 'php'=>PHP_VERSION));
    header('Location: admin.php'); exit;
  }
}
$w_data = can_write(app_path('data')); $w_up = can_write(app_path('uploads'));
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Show-Panel Installer</title>
<link rel="stylesheet" href="assets/css/style.css"><?php theme_style_tag(); ?></head>
<body class="dark"><div class="wrap">
  <h1>Show-Panel – Installation</h1>
  <?php if($errors) echo '<div class="note error">'.implode('<br>',$errors).'</div>'; ?>
  <div class="note">PHP-Version: <b><?php echo esc(PHP_VERSION); ?></b> · Schreibrechte data/: <b><?php echo $w_data?'OK':'NEIN'; ?></b> · uploads/: <b><?php echo $w_up?'OK':'NEIN'; ?></b></div>
  <form method="post" class="form">
    <div class="grid2">
      <label>Admin-Benutzer<input name="user" value="admin" required></label>
      <label>Admin-Passwort<input type="password" name="pass" value="admin123" required></label>
    </div>
    <label>Base-URL (optional)<input name="base_url" placeholder="https://example.com/tools/showpanel"></label>
    <label><input type="checkbox" name="seed" checked> Demo-Daten anlegen</label>
    <button class="btn">Jetzt installieren</button>
  </form>
</div></body></html>
