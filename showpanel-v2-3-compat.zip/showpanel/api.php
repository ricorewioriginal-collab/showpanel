<?php
define('APP',1); require __DIR__.'/lib.php';
$action = isset($_REQUEST['action'])?$_REQUEST['action']:'';
if (!is_installed() && $action!=='install') { http_response_code(400); echo 'Not installed'; exit; }

if ($action==='vote'){
  $cid = (int)(isset($_POST['cid'])?$_POST['cid']:0);
  $cands = load_json('candidates', array());
  $episodes = load_json('episodes', array());
  $cand=null; foreach($cands as $c){ if($c['id']==$cid){ $cand=$c; break; } }
  $ep=null; foreach($episodes as $e){ if($cand && $e['id']==$cand['episode_id']){ $ep=$e; break; } }
  if(!$ep || empty($ep['voting_enabled'])){ header('Content-Type: application/json'); echo json_encode(array('ok'=>false,'msg'=>'Voting deaktiviert')); exit; }

  $type = (isset($_POST['type']) && $_POST['type']==='no') ? 'no' : 'yes';
  $iplog = load_json('iplog', array());
  $key = ip_today_key($cid);
  if(isset($iplog[$key])){ header('Content-Type: application/json'); echo json_encode(array('ok'=>false,'msg'=>'Heute bereits abgestimmt')); exit; }
  $iplog[$key]=1; save_json('iplog',$iplog);
  $votes = load_json('votes', array());
  if(!isset($votes[$cid])) $votes[$cid]=array('yes'=>0,'no'=>0);
  $votes[$cid][$type]++;
  save_json('votes',$votes);
  header('Content-Type: application/json'); echo json_encode(array('ok'=>true,'yes'=>$votes[$cid]['yes'],'no'=>$votes[$cid]['no'])); exit;
}

if ($action==='apply'){
  $cand = array(
    'id'=>0,'show_id'=>(int)(isset($_POST['show_id'])?$_POST['show_id']:0),'episode_id'=>(int)(isset($_POST['episode_id'])?$_POST['episode_id']:0),
    'name'=>trim(isset($_POST['name'])?$_POST['name']:''),'city'=>trim(isset($_POST['city'])?$_POST['city']:''),'phone'=>trim(isset($_POST['phone'])?$_POST['phone']:''),
    'reason'=>trim(isset($_POST['reason'])?$_POST['reason']:''),'youtube'=>trim(isset($_POST['youtube'])?$_POST['youtube']:''),'photo'=>'','active'=>0
  );
  if(!empty($_FILES['photo']['name'])){
    $dir = __DIR__.'/uploads'; if(!is_dir($dir)) mkdir($dir,0775,true);
    $fn = time().'_'.preg_replace('~[^a-z0-9.]+~i','_', $_FILES['photo']['name']);
    if(move_uploaded_file($_FILES['photo']['tmp_name'], $dir.'/'.$fn)){ $cand['photo']='uploads/'.$fn; }
  }
  $cands = load_json('candidates', array());
  $cand['id']= next_id($cands);
  $cands[]=$cand; save_json('candidates',$cands);
  header('Location: index.php'); exit;
}

function need_admin(){ if(!is_admin()){ http_response_code(403); die('Login erforderlich'); } }

if ($action==='set_active_view'){ need_admin();
  $settings = load_json('settings', array());
  $settings['active_view']=array('show_id'=>(int)(isset($_POST['show'])?$_POST['show']:0),'episode_id'=>(int)(isset($_POST['episode'])?$_POST['episode']:0));
  save_json('settings',$settings); echo json_encode(array('ok'=>true)); exit;
}

if ($action==='save_show'){ need_admin();
  $id = (int)$_POST['show_id'];
  $shows = load_json('shows', array());
  foreach($shows as &$s){ if($s['id']==$id){ $s['title']=trim(isset($_POST['title'])?$_POST['title']:$s['title']); break; } }
  save_json('shows',$shows);
  $logo = load_json('logo', array()); $logo[$id]= trim(isset($_POST['logo'])?$_POST['logo']:'');
  save_json('logo',$logo);
  echo json_encode(array('ok'=>true)); exit;
}

if ($action==='save_episode'){ need_admin();
  $id=(int)(isset($_POST['id'])?$_POST['id']:0);
  $episodes = load_json('episodes', array());
  foreach($episodes as &$e){
    if($e['id']==$id){
      $e['title']=trim(isset($_POST['title'])?$_POST['title']:$e['title']);
      $e['type']=trim(isset($_POST['type'])?$_POST['type']:(isset($e['type'])?$e['type']:'casting'));
      $e['voting']=trim(isset($_POST['voting'])?$_POST['voting']:$e['voting']);
      $e['voting_enabled'] = !empty($_POST['voting_enabled']);
      $e['liveziel_enabled'] = !empty($_POST['liveziel_enabled']);
      $e['goal']=(int)(isset($_POST['goal'])?$_POST['goal']:$e['goal']);
      $e['gifts']=array(
        array('name'=>trim(isset($_POST['g1n'])?$_POST['g1n']:'Gift 1'),'value'=>(int)(isset($_POST['g1v'])?$_POST['g1v']:1)),
        array('name'=>trim(isset($_POST['g2n'])?$_POST['g2n']:'Gift 2'),'value'=>(int)(isset($_POST['g2v'])?$_POST['g2v']:5)),
        array('name'=>trim(isset($_POST['g3n'])?$_POST['g3n']:'Gift 3'),'value'=>(int)(isset($_POST['g3v'])?$_POST['g3v']:10)),
      );
      $e['rule']=array(
        'enabled'=>!empty($_POST['rule_enabled']),
        'required_yes'=>(int)(isset($_POST['rule_req'])?$_POST['rule_req']:2),
        'yes_threshold'=>(int)(isset($_POST['rule_thr'])?$_POST['rule_thr']:8),
        'viewer_vote_mode'=>(isset($_POST['rule_mode'])?$_POST['rule_mode']:'tool')
      );
      break;
    }
  }
  save_json('episodes',$episodes);
  echo json_encode(array('ok'=>true)); exit;
}

if ($action==='add_episode'){ need_admin();
  $show=(int)$_POST['show']; $title=trim(isset($_POST['title'])?$_POST['title']:'Neue Folge');
  $episodes = load_json('episodes', array());
  $id = next_id($episodes);
  $episodes[]=array('id'=>$id,'show_id'=>$show,'title'=>$title,'slug'=>strtolower(preg_replace('~[^a-z0-9]+~i','-',$title)),'type'=>'casting','voting'=>'regular','voting_enabled'=>false,'liveziel_enabled'=>false,'goal'=>0,'gifts'=>array(array('name'=>'Gift 1','value'=>1),array('name'=>'Gift 2','value'=>5),array('name'=>'Gift 3','value'=>10)));
  save_json('episodes',$episodes);
  echo json_encode(array('ok'=>true,'id'=>$id)); exit;
}

if ($action==='save_candidate'){ need_admin();
  $id=(int)(isset($_POST['id'])?$_POST['id']:0);
  $cands = load_json('candidates', array());
  $votes = load_json('votes', array());
  foreach($cands as &$c){
    if($c['id']==$id){
      $c['name']=trim(isset($_POST['name'])?$_POST['name']:$c['name']);
      $c['episode_id']=(int)(isset($_POST['episode_id'])?$_POST['episode_id']:$c['episode_id']);
      $c['youtube']=trim(isset($_POST['youtube'])?$_POST['youtube']:$c['youtube']);
      $c['photo']=trim(isset($_POST['photo'])?$_POST['photo']:$c['photo']);
      $c['city']=trim(isset($_POST['city'])?$_POST['city']:$c['city']);
      $c['phone']=trim(isset($_POST['phone'])?$_POST['phone']:$c['phone']);
      $c['active']= (!empty($_POST['active']) && $_POST['active']=='1') ? 1 : 0;
      break;
    }
  }
  $votes[$id]=array('yes'=>max(0,(int)(isset($_POST['yes'])?$_POST['yes']:0)),'no'=>max(0,(int)(isset($_POST['no'])?$_POST['no']:0)));
  save_json('candidates',$cands); save_json('votes',$votes);
  echo json_encode(array('ok'=>true)); exit;
}

if ($action==='add_candidate'){ need_admin();
  $cands = load_json('candidates', array());
  $id = next_id($cands);
  $cands[]=array('id'=>$id,'show_id'=>(int)(isset($_POST['show'])?$_POST['show']:0),'episode_id'=>(int)(isset($_POST['episode'])?$_POST['episode']:0),'name'=>trim(isset($_POST['name'])?$_POST['name']:'Neu'),'youtube'=>'','photo'=>'','city'=>'','phone'=>'','reason'=>'','active'=>1);
  save_json('candidates',$cands);
  echo json_encode(array('ok'=>true,'id'=>$id)); exit;
}

if ($action==='del_candidate'){ need_admin();
  $id=(int)(isset($_POST['id'])?$_POST['id']:0);
  $out=array(); foreach(load_json('candidates', array()) as $c){ if($c['id']!=$id) $out[]=$c; }
  save_json('candidates',$out); echo json_encode(array('ok'=>true)); exit;
}

if ($action==='add_juror'){ need_admin();
  $jurs = load_json('jurors', array());
  $id = next_id($jurs);
  $jurs[]=array('id'=>$id,'show_id'=>(int)(isset($_POST['show'])?$_POST['show']:0),'name'=>trim(isset($_POST['name'])?$_POST['name']:'Juror'), 'token'=>'');
  save_json('jurors',$jurs); echo json_encode(array('ok'=>true,'id'=>$id)); exit;
}

if ($action==='del_juror'){ need_admin();
  $id=(int)(isset($_POST['id'])?$_POST['id']:0);
  $out=array(); foreach(load_json('jurors', array()) as $j){ if($j['id']!=$id) $out[]=$j; }
  save_json('jurors',$out); echo json_encode(array('ok'=>true)); exit;
}

if ($action==='make_token'){ need_admin();
  $id=(int)(isset($_POST['id'])?$_POST['id']:0);
  $jurs = load_json('jurors', array()); $tok='';
  foreach($jurs as &$j){ if($j['id']==$id){ if(empty($j['token'])) $j['token']=bin2hex(random_bytes(12)); $tok=$j['token']; break; } }
  save_json('jurors',$jurs);
  $base = cfg(); $base_url = $base['base_url'];
  echo json_encode(array('ok'=>true,'url'=>$base_url.'/iframe_jury.php?token='.$tok)); exit;
}

if ($action==='set_golden_star'){ need_admin();
  $jid=(int)(isset($_POST['juror_id'])?$_POST['juror_id']:0); $cid=(int)(isset($_POST['candidate_id'])?$_POST['candidate_id']:0);
  if(!$cid){ echo json_encode(array('ok'=>false,'msg'=>'Kein Kandidat gewählt')); exit; }
  $jurs = load_json('jurors', array()); $cands = load_json('candidates', array()); $episodes = load_json('episodes', array());
  $juror=null; foreach($jurs as $j){ if($j['id']==$jid){ $juror=$j; break; } }
  $cand=null; foreach($cands as $c){ if($c['id']==$cid){ $cand=$c; break; } }
  if(!$juror || !$cand){ echo json_encode(array('ok'=>false,'msg'=>'Ungültig')); exit; }
  if($juror['show_id']!=$cand['show_id']){ echo json_encode(array('ok'=>false,'msg'=>'Show mismatch')); exit; }
  $ep=null; foreach($episodes as $e){ if($e['id']==$cand['episode_id']){ $ep=$e; break; } }
  if(!$ep || (isset($ep['type'])?$ep['type']:'')!=='casting'){ echo json_encode(array('ok'=>false,'msg'=>'Nur Casting-Episoden erlaubt')); exit; }
  $stars = load_json('jury_stars', array()); if(!isset($stars[$juror['show_id']])) $stars[$juror['show_id']]=array();
  if(isset($stars[$juror['show_id']][$jid])){ echo json_encode(array('ok'=>false,'msg'=>'Juror hat bereits vergeben')); exit; }
  $stars[$juror['show_id']][$jid]=$cid; save_json('jury_stars',$stars);
  echo json_encode(array('ok'=>true)); exit;
}

if ($action==='set_final_ticket'){ need_admin();
  $show=(int)(isset($_POST['show'])?$_POST['show']:0); $cid=(int)(isset($_POST['candidate_id'])?$_POST['candidate_id']:0);
  if(!$show || !$cid){ echo json_encode(array('ok'=>false,'msg'=>'Ungültig')); exit; }
  $cands = load_json('candidates', array());
  $ok=false; foreach($cands as $c){ if($c['id']==$cid && $c['show_id']==$show){ $ok=true; break; } }
  if(!$ok){ echo json_encode(array('ok'=>false,'msg'=>'Kandidat gehört nicht zur Show')); exit; }
  $ft = load_json('final_ticket', array()); $ft[$show]=$cid; save_json('final_ticket',$ft);
  echo json_encode(array('ok'=>true)); exit;
}

if ($action==='lz_update'){ need_admin();
  $cid=(int)(isset($_POST['cid'])?$_POST['cid']:0);
  $ep=(int)(isset($_POST['episode_id'])?$_POST['episode_id']:0);
  $g=isset($_POST['g'])?$_POST['g']:'g1';
  $delta=(int)(isset($_POST['delta'])?$_POST['delta']:1);
  $lv = load_json('liveziel', array());
  if(!isset($lv[$ep])) $lv[$ep]=array();
  $row = isset($lv[$ep][$cid]) ? $lv[$ep][$cid] : array('g1'=>0,'g2'=>0,'g3'=>0);
  $row[$g]=max(0, (int)$row[$g]+$delta);
  $lv[$ep][$cid]=$row;
  save_json('liveziel',$lv);
  echo json_encode(array('ok'=>true,'row'=>$row)); exit;
}

if ($action==='export_votes'){
  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="votes.csv"');
  $votes = load_json('votes', array()); $cands = load_json('candidates', array());
  $fp = fopen('php://output','w'); fputcsv($fp, array('CandidateID','Name','Yes','No'));
  $map = array(); foreach($cands as $c){ $map[$c['id']]=$c['name']; }
  foreach($votes as $cid=>$v){ fputcsv($fp, array($cid, isset($map[$cid])?$map[$cid]:'', (int)$v['yes'], (int)$v['no'])); }
  exit;
}
if ($action==='export_coins'){
  $ep = (int)(isset($_GET['episode_id'])?$_GET['episode_id']:0);
  header('Content-Type: text/csv; charset=utf-8');
  header('Content-Disposition: attachment; filename="coins-ep-'.$ep.'.csv"');
  $episodes = load_json('episodes', array());
  $cands = load_json('candidates', array());
  $lv = load_json('liveziel', array());
  $g = array( array('name'=>'G1','value'=>1), array('name'=>'G2','value'=>5), array('name'=>'G3','value'=>10) );
  foreach($episodes as $e){ if($e['id']==$ep){ $g=$e['gifts']; break; } }
  $fp = fopen('php://output','w'); fputcsv($fp, array('CandidateID','Name','g1','g2','g3','Coins'));
  $map = array(); foreach($cands as $c){ $map[$c['id']]=$c['name']; }
  $rows = isset($lv[$ep]) ? $lv[$ep] : array();
  foreach($rows as $cid=>$row){
    $coins = (isset($row['g1'])?$row['g1']:0)*(isset($g[0]['value'])?$g[0]['value']:1) + (isset($row['g2'])?$row['g2']:0)*(isset($g[1]['value'])?$g[1]['value']:5) + (isset($row['g3'])?$row['g3']:0)*(isset($g[2]['value'])?$g[2]['value']:10);
    fputcsv($fp, array($cid, isset($map[$cid])?$map[$cid]:'', (int)(isset($row['g1'])?$row['g1']:0), (int)(isset($row['g2'])?$row['g2']:0), (int)(isset($row['g3'])?$row['g3']:0), $coins));
  }
  exit;
}

echo 'Unknown action';
