<?php
define('APP',1); require __DIR__.'/lib.php';
if (!is_installed()) { header('Location: installer.php'); exit; }
$c = cfg(); if(session_status()===PHP_SESSION_NONE) session_start();

if(isset($_POST['do_login'])){
  $u = isset($_POST['user'])?trim($_POST['user']):''; $p = isset($_POST['pass'])?$_POST['pass']:'';
  if($u === $c['admin_user'] && password_verify($p, $c['admin_pass_hash'])){
    $_SESSION['admin_logged_in'] = 1; header('Location: admin.php'); exit;
  } else { $err="Login fehlgeschlagen"; }
}
if(isset($_GET['logout'])){ session_destroy(); header('Location: admin.php'); exit; }

if(!is_admin()):
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin Login</title>
<link rel="stylesheet" href="assets/css/style.css"><?php theme_style_tag(); ?></head>
<body class="dark"><div class="wrap small">
  <h1>Show-Panel Login</h1>
  <?php if(!empty($err)) echo '<div class="note error">'.esc($err).'</div>'; ?>
  <form method="post" class="form">
    <input name="user" placeholder="Benutzer" required>
    <input type="password" name="pass" placeholder="Passwort" required>
    <button class="btn">Login</button>
    <input type="hidden" name="do_login" value="1">
  </form>
</div></body></html><?php
exit; endif;

$shows = load_json('shows', array());
$episodes = load_json('episodes', array());
$candidates = load_json('candidates', array());
$jurors = load_json('jurors', array());
$logo = load_json('logo', array());
$settings = load_json('settings', array());
$jury_stars = load_json('jury_stars', array());
$final_ticket = load_json('final_ticket', array());

$show_id = isset($_GET['show']) ? (int)$_GET['show'] : ($shows? $shows[0]['id']:0);
$eps = arr_filter_by($episodes, 'show_id', $show_id);
$ep_id = isset($_GET['episode']) ? (int)$_GET['episode'] : ( $eps? $eps[0]['id']:0 );
?><!DOCTYPE html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Admin</title>
<link rel="stylesheet" href="assets/css/style.css"><?php theme_style_tag(); ?>
<script src="assets/js/admin.js" defer></script>
</head><body class="dark"><div class="wrap">
  <header class="header admin"><h1>Show-Panel Admin</h1><div style="flex:1"></div><a class="btn ghost" href="index.php">Viewer</a><a class="btn danger ghost" href="admin.php?logout=1">Logout</a></header>

  <form class="toolbar" method="get">
    <label>Show
      <select name="show" onchange="this.form.submit()">
        <?php foreach($shows as $s){ echo '<option value="'.$s['id'].'"'.($s['id']==$show_id?' selected':'').'>'.esc($s['title']).'</option>'; } ?>
      </select>
    </label>
    <label>Episode
      <select name="episode" onchange="this.form.submit()">
        <?php foreach($eps as $e){ echo '<option value="'.$e['id'].'"'.($e['id']==$ep_id?' selected':'').'>'.esc($e['title']).'</option>'; } ?>
      </select>
    </label>
  </form>

  <section class="card">
    <h3>Viewer-Steuerung</h3>
    <?php $av = isset($settings['active_view']) ? $settings['active_view'] : array('show_id'=>$show_id,'episode_id'=>$ep_id); ?>
    <div class="grid2"><div>
      <label>Aktive Show<select id="av_show">
        <?php foreach($shows as $s){ echo '<option value="'.$s['id'].'"'.($s['id']==(isset($av['show_id'])?$av['show_id']:0)?' selected':'').'>'.esc($s['title']).'</option>'; } ?>
      </select></label>
      <label>Aktive Episode<select id="av_episode">
        <?php foreach(arr_filter_by($episodes,'show_id',(isset($av['show_id'])?$av['show_id']:$show_id)) as $e){ echo '<option value="'.$e['id'].'"'.($e['id']==(isset($av['episode_id'])?$av['episode_id']:0)?' selected':'').'>'.esc($e['title']).'</option>'; } ?>
      </select></label>
      <button class="btn" id="set_active_view">Als Viewer aktiv setzen</button>
      <p class="small">Viewer zeigt nur diese Show/Episode.</p>
    </div></div>
  </section>

  <section class="card">
    <h3>Show</h3>
    <div class="grid2"><div>
      <label>Titel<input id="show_title" value="<?php $idx = arr_index_by_id($shows,$show_id); echo esc($idx!=-1?($shows[$idx]['title']):''); ?>"></label>
      <label>Logo-URL<input id="show_logo" value="<?php echo esc(isset($logo[$show_id])?$logo[$show_id]:''); ?>" placeholder="assets/demo/logo.png"></label>
      <button class="btn" id="save_show" data-show="<?php echo (int)$show_id; ?>">Speichern</button>
    </div><div><img class="photo" style="max-height:140px;object-fit:contain;background:#000" src="<?php echo esc(isset($logo[$show_id])?$logo[$show_id]:(isset($settings['logo_default'])?$settings['logo_default']:'assets/demo/logo.png')); ?>"></div></div>
  </section>

  <section class="card">
    <h3>Folgen</h3>
    <table class="table" id="ep_table">
      <thead><tr><th>Titel</th><th>Typ</th><th>Voting</th><th>Regel (2×JA)</th><th>Aktivierungen</th><th>Goal</th><th>Gifts</th><th>Aktion</th></tr></thead>
      <tbody>
      <?php foreach($eps as $e): $r = isset($e['rule'])?$e['rule']:array('enabled'=>false,'required_yes'=>2,'yes_threshold'=>8,'viewer_vote_mode'=>'tool'); ?>
        <tr data-ep="<?php echo $e['id']; ?>">
          <td><input class="w200 ep-title" value="<?php echo esc($e['title']); ?>"></td>
          <td><select class="ep-type">
            <?php $types=array('wildcard'=>'Wildcard','casting'=>'Casting','recall'=>'Recall','motto'=>'Mottoshow','finale'=>'Finale'); foreach($types as $k=>$v){ echo '<option value="'.$k.'"'.(($e['type']==$k)?' selected':'').'>'.$v.'</option>'; } ?>
          </select></td>
          <td><select class="ep-voting"><?php $vv=array('regular'=>'Regulär','esc'=>'ESC','coins'=>'Coins','mixed'=>'Gemischt'); foreach($vv as $k=>$v){ echo '<option value="'.$k.'"'.(($e['voting']==$k)?' selected':'').'>'.$v.'</option>'; } ?></select></td>
          <td class="small">
            <label class="switch"><input class="ep-rule-en" type="checkbox" <?php echo !empty($r['enabled'])?'checked':''; ?>><span></span></label> aktiv ·
            Req <input class="w60 ep-rule-req" type="number" value="<?php echo (int)$r['required_yes']; ?>"> ·
            JA ab <input class="w60 ep-rule-thr" type="number" value="<?php echo (int)$r['yes_threshold']; ?>"> ·
            Viewer <select class="ep-rule-mode"><option value="tool" <?php echo ($r['viewer_vote_mode']=='tool')?'selected':''; ?>>Tool</option><option value="tiktok" <?php echo ($r['viewer_vote_mode']=='tiktok')?'selected':''; ?>>TikTok</option></select>
          </td>
          <td class="small">
            <label class="switch"><input class="ep-ven" type="checkbox" <?php echo !empty($e['voting_enabled'])?'checked':''; ?>><span></span></label> Voting
            &nbsp;
            <label class="switch"><input class="ep-lzen" type="checkbox" <?php echo !empty($e['liveziel_enabled'])?'checked':''; ?>><span></span></label> Liveziel
          </td>
          <td><input type="number" class="w120 ep-goal" value="<?php echo (int)$e['goal']; ?>"></td>
          <td class="small">
            1: <input class="w120 ep-g1-name" value="<?php echo esc(isset($e['gifts'][0]['name'])?$e['gifts'][0]['name']:'Gift 1'); ?>"> × <input class="w60 ep-g1-val" type="number" value="<?php echo (int)(isset($e['gifts'][0]['value'])?$e['gifts'][0]['value']:1); ?>"><br>
            2: <input class="w120 ep-g2-name" value="<?php echo esc(isset($e['gifts'][1]['name'])?$e['gifts'][1]['name']:'Gift 2'); ?>"> × <input class="w60 ep-g2-val" type="number" value="<?php echo (int)(isset($e['gifts'][1]['value'])?$e['gifts'][1]['value']:5); ?>"><br>
            3: <input class="w120 ep-g3-name" value="<?php echo esc(isset($e['gifts'][2]['name'])?$e['gifts'][2]['name']:'Gift 3'); ?>"> × <input class="w60 ep-g3-val" type="number" value="<?php echo (int)(isset($e['gifts'][2]['value'])?$e['gifts'][2]['value']:10); ?>">
          </td>
          <td><button class="btn tiny save-ep">Speichern</button></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <div class="grid2"><input id="new_ep_title" placeholder="Neue Folge Titel"><button class="btn" id="add_episode" data-show="<?php echo (int)$show_id; ?>">+ Folge anlegen</button></div>
  </section>

  <section class="card">
    <h3>Kandidaten</h3>
    <table class="table" id="cand_table">
      <thead><tr><th>Name</th><th>Media</th><th>Status</th><th>Ja</th><th>Nein</th><th>Aktion</th></tr></thead>
      <tbody>
      <?php $votes = load_json('votes',array());
      foreach($candidates as $cand){ if($cand['show_id']==$show_id && (!$ep_id || $cand['episode_id']==$ep_id)){
        $vv= isset($votes[$cand['id']])?$votes[$cand['id']]:array('yes'=>0,'no'=>0); ?>
        <tr data-cid="<?php echo $cand['id']; ?>">
          <td><input class="w200 cand-name" value="<?php echo esc($cand['name']); ?>"><div class="small">ID: <?php echo $cand['id']; ?> · Episode: <input class="w80 cand-ep" type="number" value="<?php echo (int)$cand['episode_id']; ?>"></div></td>
          <td class="small">
            <input class="w240 cand-yt" value="<?php echo esc(isset($cand['youtube'])?$cand['youtube']:''); ?>" placeholder="YouTube-Link">
            <input class="w240 cand-photo" value="<?php echo esc(isset($cand['photo'])?$cand['photo']:''); ?>" placeholder="Foto-URL (Fallback)">
          </td>
          <td><label class="switch"><input class="cand-active" type="checkbox" <?php echo !empty($cand['active'])?'checked':''; ?>><span></span></label></td>
          <td><input class="w80 cand-yes" type="number" value="<?php echo (int)$vv['yes']; ?>"></td>
          <td><input class="w80 cand-no" type="number" value="<?php echo (int)$vv['no']; ?>"></td>
          <td><button class="btn tiny save-cand">Speichern</button> <button class="btn tiny danger del-cand">Löschen</button></td>
        </tr>
      <?php }} ?>
      </tbody>
    </table>
    <div class="grid2"><input id="new_cand_name" placeholder="Neuer Kandidat Name"><button class="btn" id="add_candidate" data-show="<?php echo (int)$show_id; ?>" data-episode="<?php echo (int)$ep_id; ?>">+ Kandidat anlegen</button></div>
  </section>

</div></body></html>
